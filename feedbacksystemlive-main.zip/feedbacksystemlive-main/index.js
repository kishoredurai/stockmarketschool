const express = require("express");
const multer = require("multer");
const path = require("path");
const app = express();
const PORT = 3001;
app.use(express.static(path.join(__dirname, 'build')));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
const createUUID = () => {
  let dt = new Date().getTime();
  const uuid = "-xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    const r = (dt + Math.random() * 16) % 16 | 0;
    dt = Math.floor(dt / 16);
    return (c == "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
  return uuid;
};

const fileFilter = (req, file, cb) => {
  if (
    file.mimetype == "image/jpeg" ||
    file.mimetype == "image/png" ||
    file.mimetype == "application/pdf"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.post("/api/upload", (request, response, next) => {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "uploads");
    },
    filename: (req, file, cb) => {
      const fileName =
        Date.now() + createUUID() + path.extname(file.originalname);
      cb(null, fileName);
    },
  });
  const upload = multer({ storage: storage, fileFilter: fileFilter }).array(
    "feed_image",
    3
  );
  upload(request, response, function (err) {
    if (err) {
      response.status(403).json({ message: "Error in Uploading!" });
    } else {
      response.status(201).json(request.files);
    }
  });
});
app.listen(PORT, () =>
  console.log(`Feedback System Backend app listening on port ${PORT}!`)
);
